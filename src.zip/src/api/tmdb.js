// src/api/tmdb.js
import axios from 'axios';
import { setMovies } from '../slice/movieSlice';

const API_KEY  = process.env.REACT_APP_TMDB_API_KEY;
const BASE_URL = 'https://api.themoviedb.org/3';
const IMG_BASE = 'https://image.tmdb.org/t/p/w342';   // lighter poster size

/* ──────────────  GENRE MAP (cached once)  ────────────── */
let genreMap = {};
const fetchGenreMap = async () => {
  if (Object.keys(genreMap).length) return genreMap;   // already cached

  try {
    const { data } = await axios.get(`${BASE_URL}/genre/movie/list`, {
      params: { api_key: API_KEY, language: 'en-US' },
    });
    data.genres.forEach((g) => (genreMap[g.id] = g.name));
  } catch (err) {
    console.error('Genre list fetch failed:', err.message);
  }
  return genreMap;
};

/* ──────────────  SHAPE MOVIE OBJECT  ────────────── */
const shapeMovie = (movie) => ({
  imdbId: movie.id,
  title: movie.title,
  year: movie.release_date?.split('-')[0] || '',
  rating: movie.vote_average?.toFixed(1) || 'N/A',
  description: movie.overview || 'No description.',
  actors: 'N/A',                               // cast omitted to save API calls
  genres: movie.genre_ids.map((id) => genreMap[id] || 'Unknown'),
  image: movie.poster_path ? `${IMG_BASE}${movie.poster_path}` : null,
});

/* ──────────────  POPULAR LIST (Paginated)  ────────────── */
export const getPopularMovies = (page = 1) => async (dispatch) => {
  try {
    await fetchGenreMap();

    const { data } = await axios.get(`${BASE_URL}/movie/popular`, {
      params: { api_key: API_KEY, language: 'en-US', page },
    });

    // Keep exactly 12 for the current page
    const movies = data.results.slice(0, 12).map(shapeMovie);

    dispatch(setMovies(movies));
  } catch (err) {
    console.error('Popular movies fetch failed:', err.message);
    dispatch(setMovies([]));
  }
};

/* ──────────────  SEARCH  ────────────── */
export const searchMovies = (query) => async (dispatch) => {
  if (!query.trim()) return dispatch(getPopularMovies(1));

  try {
    await fetchGenreMap();

    const { data } = await axios.get(`${BASE_URL}/search/movie`, {
      params: {
        api_key: API_KEY,
        language: 'en-US',
        query,
        page: 1,
        include_adult: false,
      },
    });

    // // Exact‑match optimisation
    const exact = data.results.includes(
      (m) => m.title.toLowerCase().trim() === query.toLowerCase().trim()
    );

    const list = exact ? [exact] : data.results.slice(0, 12); // 12 max
    dispatch(setMovies(list.map(shapeMovie)));
  } catch (err) {
    console.error('Search failed:', err.message);
    dispatch(setMovies([]));
  }
};
