import React from 'react';
import { Card, CardContent, Skeleton, Box } from '@mui/material';

const MovieCardSkeleton = () => {
  return (
    <Card sx={{ width: 250, height: 420 }}>
      <Skeleton variant="rectangular" width="100%" height={300} />
      <CardContent>
        <Skeleton variant="text" width="80%" height={24} />
        <Skeleton variant="text" width="60%" height={18} />
        <Skeleton variant="text" width="40%" height={18} />
      </CardContent>
    </Card>
  );
};

export default MovieCardSkeleton;
