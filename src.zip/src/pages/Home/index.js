// src/pages/Home.jsx
import React, { useEffect, useMemo } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import Container from '@mui/material/Container';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';

import MovieCard from '../../components/MovieCard';
import { getPopularMovies, searchMovies } from '../../api/tmdb';
import { debounce } from 'lodash';
import Navbar from '../../components/Navbar';

const Home = () => {
  const dispatch = useDispatch();
  const movies = useSelector((state) => state.movies.movies);

  useEffect(() => {
    dispatch(getPopularMovies());
  }, [dispatch]);

  const debouncedSearch = useMemo(
    () => debounce((query) => dispatch(searchMovies(query)), 500),
    [dispatch]
  );

  useEffect(() => () => debouncedSearch.cancel(), [debouncedSearch]);

  return (
    <Navbar onSearch={debouncedSearch}></Navbar>
    <Container maxWidth="lg" sx={{ mt: 4, mb: 6 }}>
      
      {movies.length === 0 ? (
        <Typography variant="h6" align="center">No movies found.</Typography>
      ) : (
        <Box
          sx={{
            display: 'flex',
            flexWrap: 'wrap',
            gap: 2,
            justifyContent: 'center',
          }}
        >
          {movies.map((movie) => (
            <Box
              key={movie.imdbId}
              sx={{
                flexGrow: 1,
                flexBasis: {
                  xs: '100%',
                  sm: 'calc(50% - 16px)',
                  md: 'calc(50% - 16px)',
                  lg: 'calc(25% - 16px)',
                },
                display: 'grid',
              }}
            >
              <MovieCard {...movie} />
            </Box>
          ))}
        </Box>
      )}
    </Container>
  );
};

export default Home;
